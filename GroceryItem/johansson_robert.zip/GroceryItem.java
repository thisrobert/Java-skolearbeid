
//GROCERYITEM
/**
 * Write a description of class GroceryItem here.
 * 
 * @Robert Johansson 
 * @version (a version number or a date)
 */
public class GroceryItem
{
    // instance variables - replace the example below with your own
    private String name;
    private double pricePerUnit;

    public GroceryItem()
    {
        name = "Ukjent";
        pricePerUnit = 0;
    }

    public GroceryItem(String ItemName, double price)
    {
        name = ItemName;
        pricePerUnit = price;
    }

    public void setName(String ItemName)
    {
        name = ItemName;
    }

    public void setPricePerUnit(double price)
    {
        pricePerUnit = price;
    }

    public String getName()
    {
        return name;
    }

    public double getPricePerUnit()
    {
        return pricePerUnit;
    }

}
//CLIENT
/**
 * Write a description of class Client here.
 * 
 * @Robert
 * @version (a version number or a date)
 */
public class Client
{
    private GroceryItem vare1;
    private GroceryItem vare2;
    private double PriceTotal;

    public Client()
    {
        clientMethod();

    }

    public void clientMethod()
    {
        vare1 = new GroceryItem("Brunost", 15.9);
        vare2 = new GroceryItem("Lettmelk", 8.5);
        PriceTotal = vare1.getPricePerUnit() + vare2.getPricePerUnit();

        System.out.println("Varens navn: " + vare1.getName() + "\n" + 
            "Varens pris: " + vare1.getPricePerUnit() + "\n" + 
            "Varens navn: " + vare2.getName() + "\n" + 
            "Varens pris: " + vare2.getPricePerUnit() + "\n" + 
            "Varene " + vare1.getName() + " og " + vare2.getName() + " kostet til sammen " + PriceTotal);
    }

}
